# spider-fb
Perintah :

$pkg update &amp;&amp; pkg upgrade  
$pkg install python2  
$pkg install git  
$git clone https://github.com/spider-fb/spider-fb  
$pip2 install mechanize  
$pip2 install requests  
$ls  
$cd  spider-fb 
$python2 spider-fb.py  
Usernam: anak

Pass: binjai

Download lisensi Scriptnya disini : https://tatawirdat.blogspot.com  

Don't forget to subscribe to the YouTube channel, please

https://www.youtube.com/channel/UCP0-8OzsHywqN461bVFjUbQ

Cara agar terhindar dari cekpoint: 
https://www.mediafire.com/download/608fmflx9imf2d4
